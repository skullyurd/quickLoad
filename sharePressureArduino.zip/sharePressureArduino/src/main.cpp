#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BME280.h>
#include <SPI.h>
#include <mcp_can.h>
#include <mcp2515_can.h>

#define SEALEVELPRESSURE_HPA (1013.25)
#define CS_PIN 10  // Chip Select pin for MCP251

Adafruit_BME280 bme;
mcp2515_can CAN(CS_PIN); // Set CS pin

void setup() {
	Serial.begin(9600);

	if (!bme.begin(0x76)) {
		Serial.println("Could not find a valid BME280 sensor, check wiring!");
		while (1);
	}

  while (CAN_OK != CAN.begin(CAN_500KBPS))
    {
        Serial.println("CAN BUS init Failed");
        delay(100);
    }
    Serial.println("CAN BUS Shield Init OK!");
  
}

void loop() {
    Serial.print("Temperature = ");
    Serial.print(bme.readTemperature());
    Serial.println("*C");

    Serial.print("Pressure = ");
    float pressure = bme.readPressure() / 100.0F; // Pressure in hPa
    Serial.print(pressure);
    Serial.println(" hPa");

    // Convert float to byte array
    unsigned char pressureBytes[4];
    memcpy(pressureBytes, &pressure, sizeof(pressure));

    // Send pressure data over CAN bus
    CAN.sendMsgBuf(0x13, 0, sizeof(pressureBytes), pressureBytes);

    // Print out the pressure data for debugging
    Serial.print("CAN BUS Shield send pressure: ");
    for (int i = 0; i < sizeof(pressureBytes); i++) {
        Serial.print(pressureBytes[i], HEX);
        Serial.print("\t");
    }
    CAN.checkReceive(); // Check if data is received
    Serial.println();

    delay(100);

    Serial.print("Approx. Altitude = ");
    Serial.print(bme.readAltitude(SEALEVELPRESSURE_HPA));
    Serial.println("m");

    Serial.print("Humidity = ");
    Serial.print(bme.readHumidity());
    Serial.println("%");

    Serial.println();
    delay(1000);
}